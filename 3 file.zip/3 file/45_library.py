import math

print(math.sqrt(16))       
print(math.factorial(5))   
print(math.pi)             
