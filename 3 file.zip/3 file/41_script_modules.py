#script with two modules,import one into the other and call a function

def greet(name):
    return f"Hello, {name}!"



