import 41_script_module

print(41_script_module.greet("Python"))
