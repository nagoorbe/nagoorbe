class NumberCheck:
    @staticmethod
    def is_even(num):
        return num % 2 == 0


print(NumberCheck.is_even(10)) 
print(NumberCheck.is_even(7))  
